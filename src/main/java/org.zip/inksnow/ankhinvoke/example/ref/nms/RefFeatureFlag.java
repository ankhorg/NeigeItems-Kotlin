package org.inksnow.ankhinvoke.example.ref.nms;

import org.inksnow.ankhinvoke.comments.HandleBy;

@HandleBy(reference = "net/minecraft/world/flag/FeatureFlag", predicates = "craftbukkit_version:[v1_17_R1,)")
public final class RefFeatureFlag {

}
